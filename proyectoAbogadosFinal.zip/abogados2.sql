-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 13-07-2022 a las 05:41:58
-- Versión del servidor: 10.4.22-MariaDB
-- Versión de PHP: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `abogados2`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `datos_personales`
--

CREATE TABLE `datos_personales` (
  `num_documento` varchar(25) NOT NULL,
  `tipo_documento` int(2) NOT NULL,
  `nombres` varchar(50) NOT NULL,
  `apellidos` varchar(50) NOT NULL,
  `fecha_naci` date NOT NULL,
  `genero` varchar(20) NOT NULL,
  `celular` varchar(20) NOT NULL,
  `direccion` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `telefono` varchar(50) NOT NULL,
  `id_usuario` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `datos_personales`
--

INSERT INTO `datos_personales` (`num_documento`, `tipo_documento`, `nombres`, `apellidos`, `fecha_naci`, `genero`, `celular`, `direccion`, `email`, `telefono`, `id_usuario`) VALUES
('1040742333', 1, 'Pedro', 'Juarez', '2022-07-01', 'M', '3004868672', 'Unit 3009/180 City Road - Southbank', 'cami_og02@hotmail.com', '0402979083', 28),
('10407428365', 1, 'mariana', 'giraldo', '2022-06-01', 'F', '3004868672', '180 City Road', 'kmylaog@gmail.com', '0402979083', 27),
('1040742852', 2, 'Maria Camila', 'Ocampo Giraldo', '2022-07-08', 'M', '3004868672', 'Unit 3009/180 City Road - Southbank', 'cami_og02@hotmail.com', '0402979083', 23),
('1040742858', 1, 'Maria Paulinas', 'Ocampo Giraldos', '2022-07-08', 'M', '3004868672', 'Antioquia', 'cami_og02@hotmail.com', '0402979083', 16),
('1040742859', 1, 'Santiago', 'Alzate Posada', '2022-06-30', 'F', '3004868672', 'Medellin', 'cami_og02@hotmail.com', '0402979083', 19),
('10407428800', 1, 'Maria Camila', 'Ocampo Giraldo', '2022-06-24', 'M', '3004868672', 'Unit 3009/180 City Road - Southbank', 'cami_og02@hotmail.com', '0402979083', 26),
('9876', 4, 'Piero andres', 'Verde londoño', '2009-06-10', 'M', '3146157899', 'carrera 43', 'piero@hotmail.com', '44555667', 42);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalles_proceso`
--

CREATE TABLE `detalles_proceso` (
  `id_detalle_proceso` int(4) NOT NULL,
  `radicado_proceso` int(50) NOT NULL,
  `tipo_proceso` int(11) NOT NULL,
  `asunto_proceso` varchar(50) NOT NULL,
  `demandante` varchar(50) NOT NULL,
  `demandado` varchar(50) NOT NULL,
  `juzgado` varchar(50) NOT NULL,
  `ciudad` varchar(30) NOT NULL,
  `fecha_demanda` date NOT NULL,
  `pretensiones` varchar(500) NOT NULL,
  `fecha_contestacion` date NOT NULL,
  `excepciones` varchar(500) DEFAULT NULL,
  `fecha_audiencia1` date DEFAULT NULL,
  `observaciones` varchar(500) DEFAULT NULL,
  `fecha_audiencia2` date DEFAULT NULL,
  `fecha_audiencia3` date DEFAULT NULL,
  `fecha_audiencia4` date DEFAULT NULL,
  `num_documento` varchar(50) NOT NULL,
  `cargar_archivos` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `detalles_proceso`
--

INSERT INTO `detalles_proceso` (`id_detalle_proceso`, `radicado_proceso`, `tipo_proceso`, `asunto_proceso`, `demandante`, `demandado`, `juzgado`, `ciudad`, `fecha_demanda`, `pretensiones`, `fecha_contestacion`, `excepciones`, `fecha_audiencia1`, `observaciones`, `fecha_audiencia2`, `fecha_audiencia3`, `fecha_audiencia4`, `num_documento`, `cargar_archivos`) VALUES
(2, 555555, 1, 'Demanda civil', 'Pablo Perez', 'Gabriela', 'septimo civil', 'Medellin', '2022-07-04', 'ganarla', '2022-07-07', 'perder', '2022-08-11', 'hay que ganar', '2022-09-02', '2022-10-14', '2022-11-11', '1040742333', ''),
(4, 0, 2, 'muerte', 'Juan Guarin Madrigal', 'Pedro Infante', 'Noveno penal', 'medellin', '2022-07-04', 'carcel', '2022-07-07', 'dddd', '2022-07-08', 'dddd', '2022-07-16', '2022-07-21', '2022-07-23', '1026139914', ''),
(5, 66999, 3, 'trabajo', 'camila ocampo', 'Pedro Infante', 'Noveno laboral', 'medellin', '2022-07-07', 'ganar', '2022-07-22', '', '2022-07-22', 'sss', '0000-00-00', '0000-00-00', '0000-00-00', '8888', ''),
(6, 66666, 1, 'venta', 'orlando', 'olga', 'cuarto', 'envigado', '2022-07-05', 'todas', '2022-07-12', 'nada', '2022-07-21', 'fre', '2022-07-15', '2022-07-06', '2022-07-19', '12345', 'Certificado ProtecciÃ³n (1).pdf'),
(7, 8896654, 1, 'robo', 'alvaro', 'petter', 'segundo', 'florida', '2022-07-05', 'jugar', '2022-07-12', 'nada', '2022-07-12', 'moda', '2022-07-13', '2022-07-06', '2022-07-23', '96325', ''),
(8, 6666, 1, 'futbol', 'felipe guarin', 'carlos sanchez', 'unico', 'caldas', '2022-07-05', 'jugar futbol', '2022-07-14', 'perder', '2022-07-13', 'empatar', '2022-07-22', '2022-07-23', '2022-07-25', '1230255', 'Certificado_afiliacion_Sanitas.pdf'),
(9, 9874, 2, 'trabajo', 'Pablo ', 'petter', 'Noveno penal', 'florida', '2022-07-05', 'ganarla ', '2022-07-12', 'perde', '2022-07-14', 'ninguna', '2022-07-21', '2022-07-24', '2022-07-30', '12345', 'WhatsApp Image 2022-05-22 at 8.27.33 AM.jpeg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `perfil`
--

CREATE TABLE `perfil` (
  `id_perfil` int(2) NOT NULL,
  `nombre_perfil` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `perfil`
--

INSERT INTO `perfil` (`id_perfil`, `nombre_perfil`) VALUES
(10, 'Directivo'),
(11, 'cliente'),
(12, 'Abogado'),
(13, 'Secretaria');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_documentos`
--

CREATE TABLE `tipo_documentos` (
  `id_tipo_documento` int(2) NOT NULL,
  `nombre_documento` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tipo_documentos`
--

INSERT INTO `tipo_documentos` (`id_tipo_documento`, `nombre_documento`) VALUES
(1, 'Cedula'),
(2, 'Cedula Extranjeria'),
(3, 'Pasaporte'),
(4, 'Tarjeta de Identidad');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_proceso`
--

CREATE TABLE `tipo_proceso` (
  `id_tipo_proceso` int(11) NOT NULL,
  `nombre_proceso` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tipo_proceso`
--

INSERT INTO `tipo_proceso` (`id_tipo_proceso`, `nombre_proceso`) VALUES
(1, 'Civil'),
(2, 'Laboral'),
(3, 'Penal');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuario` int(4) NOT NULL,
  `contrasena` varchar(15) NOT NULL,
  `estado` varchar(25) NOT NULL,
  `id_perfil` int(2) NOT NULL,
  `nombre_usuario` varchar(50) NOT NULL,
  `fecha_registro` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `contrasena`, `estado`, `id_perfil`, `nombre_usuario`, `fecha_registro`) VALUES
(16, '567', 'Activo', 12, 'Hector01', '2022-03-09'),
(17, '1234', 'Inactivo', 10, 'pedro angulo', '2022-03-30'),
(18, '8888', 'Inactivo', 11, 'lola', '2022-04-05'),
(19, 'd1026139914', 'Activo', 11, 'juanguarin1026', '2022-04-06'),
(21, '2233', 'Inactivo', 10, 'pipe guarin', '2022-05-11'),
(23, '4567', 'Activo', 11, 'camila ocampo', '2022-05-10'),
(24, '2233', 'Inactivo', 11, 'camila ocampo', '2022-05-06'),
(25, '1090', 'Inactivo', 11, 'karen sanchez', '2022-05-25'),
(26, '100', 'Activo', 12, 'gustavo bolivar', '2022-05-26'),
(27, '12345', 'Activo', 11, 'santialpo', '2022-06-08'),
(28, '12345', 'Activo', 13, 'Hector02', '2022-06-24'),
(29, '12345', 'Activo', 11, 'Santiago1234', '2022-07-07'),
(30, '3344', 'Activo', 11, 'jose perea', '2022-06-14'),
(31, '2233', 'Activo', 11, 'petrona', '2022-06-23'),
(32, '4321', 'Activo', 11, 'Camilo gomez', '2022-06-25'),
(37, '2233', 'Activo', 11, 'lolalanda', '2022-06-25'),
(38, '000332', 'Inactivo', 10, 'saniago perez', '2022-06-02'),
(39, '789', 'Activo', 11, 'ñato', '2022-06-29'),
(40, '55555566666', 'Activo', 11, 'mauricio123', '2022-07-12'),
(41, '$2y$10$jumK/s.H', 'Activo', 12, 'PEPITO', '2022-07-11'),
(42, '$2y$10$CDRopOhC', 'Activo', 13, 'piero verde', '2022-07-12');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `datos_personales`
--
ALTER TABLE `datos_personales`
  ADD PRIMARY KEY (`num_documento`),
  ADD KEY `id_usuario` (`id_usuario`),
  ADD KEY `tipo_documento` (`tipo_documento`);

--
-- Indices de la tabla `detalles_proceso`
--
ALTER TABLE `detalles_proceso`
  ADD PRIMARY KEY (`id_detalle_proceso`),
  ADD KEY `radicado_proceso` (`radicado_proceso`),
  ADD KEY `tipo_proceso` (`tipo_proceso`),
  ADD KEY `num_documento` (`num_documento`);

--
-- Indices de la tabla `perfil`
--
ALTER TABLE `perfil`
  ADD PRIMARY KEY (`id_perfil`) USING BTREE;

--
-- Indices de la tabla `tipo_documentos`
--
ALTER TABLE `tipo_documentos`
  ADD PRIMARY KEY (`id_tipo_documento`);

--
-- Indices de la tabla `tipo_proceso`
--
ALTER TABLE `tipo_proceso`
  ADD PRIMARY KEY (`id_tipo_proceso`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuario`),
  ADD KEY `perfil` (`id_perfil`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `detalles_proceso`
--
ALTER TABLE `detalles_proceso`
  MODIFY `id_detalle_proceso` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `perfil`
--
ALTER TABLE `perfil`
  MODIFY `id_perfil` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `tipo_documentos`
--
ALTER TABLE `tipo_documentos`
  MODIFY `id_tipo_documento` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `tipo_proceso`
--
ALTER TABLE `tipo_proceso`
  MODIFY `id_tipo_proceso` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuario` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `datos_personales`
--
ALTER TABLE `datos_personales`
  ADD CONSTRAINT `datos_personales_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`),
  ADD CONSTRAINT `datos_personales_ibfk_2` FOREIGN KEY (`tipo_documento`) REFERENCES `tipo_documentos` (`id_tipo_documento`);

--
-- Filtros para la tabla `detalles_proceso`
--
ALTER TABLE `detalles_proceso`
  ADD CONSTRAINT `detalles_proceso_ibfk_2` FOREIGN KEY (`tipo_proceso`) REFERENCES `tipo_proceso` (`id_tipo_proceso`);

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`id_perfil`) REFERENCES `perfil` (`id_perfil`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
