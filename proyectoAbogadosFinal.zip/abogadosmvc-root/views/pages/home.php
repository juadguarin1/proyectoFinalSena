<BR></BR>
<HR></HR>
<div class="card">
  <h5 class="card-header">ABOGADOS</h5>
  <div class="card-body">
    <img src="..\abogadosmvc-root\views\pages\image\abogados.jpg" class="img-fluid" >
    


  
  </div>
</div>