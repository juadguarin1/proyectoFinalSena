<br>
<div class="card">
    <div class="card-header bg-dark text-white">
       Datos Personales
    </div>
<div class="card-body">
            <form action="?controller=datospersonales&action=enviarDatosPersonales" method="post">
                <div class="mb-3 row">
                    <label for="" class="col-sm-2 form-label">Numero Documento:</label>
                <div class="col-sm-10">
                        <input type="hidden" class="form-control" name="txtid_usuario" value="<?php echo $datosPersonales->id_usuario?>">
                        <input type="text" class="form-control" name="txtnumdocumento" value="<?php echo $datosPersonales->num_documento?>">
                </div>
                </div>

                <div class="mb-3 row">
                <label for="" class="col-sm-2 form-label">Tipo Documento:</label>
                <div class="col-sm-10">
                    <select name="cboid_tipodocumento" id="" class="form-control">
                            <option value="">Seleccione Tipo de Documento</option>
                                <?php foreach($tiposDocumento as $td) :?>
                                    <option value="<?php echo $td->id_tipo_documento?>" <?php echo $datosPersonales->tipo_documento==$td->id_tipo_documento ? 'selected': ''?>><?php echo $td->nombre_documento?></option>
                                <?php endforeach?>
                    </select>
                </div>
                </div>

                <div class="mb-3 row">
                    <label for="" class="col-sm-2 form-label">Nombres</label>
                <div class="col-sm-10">
                    <input type="text" name="txtnombre_usuario" class= "form-control" value="<?php echo $datosPersonales->nombres?>">
                </div>
                </div>

                <div class="mb-3 row">
                    <label for="" class="col-sm-2 form-label">Apellidos</label>
                <div class="col-sm-10">
                    <input type="text" name="txtapellidos" class= "form-control" value="<?php echo $datosPersonales->apellidos?>">
                </div>
                </div>

                <div class="mb-3 row">
                    <label for="" class="col-sm-2 form-label">Fecha de Nacimiento</label>
                <div class="col-sm-10">
                    <input type="date" name="fecha_naci" class= "form-control" value="<?php echo $datosPersonales->fecha_naci?>">
                </div>
                </div>

                <div class="mb-3 row">
                    <label for="" class="col-sm-2 form-label">Genero</label>
                <div class="col-sm-10">
                <select name="cbogenero" id="" class="form-control">
                            <option value="">Seleccione Genero</option>
                            <option value="F" <?php echo $datosPersonales->genero=='F' ? 'selected': ''?>>Femenino</option>
                            <option value="M" <?php echo $datosPersonales->genero=='M' ? 'selected': ''?>>Masculino</option>
                </select>
                </div>
                </div>

                <div class="mb-3 row">
                    <label for="" class="col-sm-2 form-label">Nùmero de Celular</label>
                <div class="col-sm-10">
                <input type="text" class="form-control" name="txtcelular" value="<?php echo $datosPersonales->celular?>">
                </div>
                </div>


                <div class="mb-3 row">
                    <label for="" class="col-sm-2 form-label">Direcciòn</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="txtdireccion" value="<?php echo $datosPersonales->direccion?>">
                </div>
                </div>

                <div class="mb-3 row">
                    <label for="" class="col-sm-2 form-label">Email</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="txtemail" value="<?php echo $datosPersonales->email?>">
                </div>
                </div>


                <div class="mb-3 row">
                    <label for="" class="col-sm-2 form-label">Telefono</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="txtelefono" value="<?php echo $datosPersonales->telefono?>">
                </div>
                </div>


                <div class="mb-3 row">
                <div class="col-sm-2"></div>
                <div class="col-sm-10">
                    <input type="submit" class="btn btn-primary btn-lg" name="Guardar" id="Guardar" value="Guardar" >
                </div>
                </div>
            </form>
</div>
</div>

<script src="Resources/js/jquery-3.6.0.js"></script>
<script src="Resources/js/materialize.js"></script>
<script>
    $(document).ready(function(){
        $('select').formSelect();
        });
</script>
</body>
</html>