<br/>
<div class="card">
    <div class="card-header bg-dark text-white">
        Actualizar Usuario
    </div>
    <div class="card-body">
        <form action="?controller=usuarios&action=guardarEdicion" method="post">
            
            <div class="mb-3 row">
                <label for="" class="col-sm-2 form-label">Nombre Usuario</label>
                <div class="col-sm-10">
                    
                <input type="hidden" name="id_usuario" value= "<?php echo $usuario->id_usuario?>">
                    <input type="text" class="form-control" name="NombreUsuario" id="NombreUsuario" value= "<?php echo $usuario->nombre_usuario?>" >
                </div>

            </div>
            <div class="mb-3 row">
                <label for="" class="col-sm-2 form-label">Contraseña</label>
                <div class="col-sm-10">
                    <input type="password" class="form-control" name="Contrasena" id="Contrasena" value= "<?php echo $usuario->contrasena?>" >
                </div>
            </div>
            <div class="mb-3 row">
                <label for="" class="col-sm-2 form-label">Fecha de Registro</label>
                <div class="col-sm-10">
                    <input type="date" class="form-control" name="FechaRegistro" id="FechaRegistro" value= "<?php echo $usuario->fecha_registro?>">
                </div>
            </div>
            <div class="mb-3 row">
                <label for="" class="col-sm-2 form-label">Perfil</label>
                <div class="col-sm-10">
                    <select name="Perfil" id="Perfil" class="form-control">
                        <option value="" selected>Seleccione el perfil</option>                       
                        <?php foreach($perfiles as $p) :?>
                            
                        <option value="<?php echo $p->id_perfil?>" <?php echo $usuario->id_perfil==$p->id_perfil ? 'selected': ''?>><?php echo $p->nombre_perfil?></option>
                        <?php endforeach?> 
                    </select>
                    
                </div>
            </div>
            <div class="mb-3 row">
                <label for="" class="col-sm-2 form-label">Estado</label>
                <div class="col-sm-10">
                    <select name="Estado" id="Estado" class="form-control">
                        <option value="" selected>Seleccione el estado</option>                       
                        <?php foreach($estados as $e) :?>                      
                        <option value="<?php echo $e?>" <?php echo $usuario->estado==$e ? 'selected': ''?>><?php echo $e?></option>
                        <?php endforeach?> 
                    </select>
                </div>
            </div>
            <div class="mb-3 row">
                <div class="col-sm-2"></div>
                <div class="col-sm-10">
                    <input type="submit" class="btn btn-primary btn-lg" name="Actualizar" id="Actualizar" value="Actualizar" >
                </div>
            </div>

        </form>
    </div>
</div>