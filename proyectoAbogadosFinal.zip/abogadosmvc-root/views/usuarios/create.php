<br>
<div class="card">
    <div class="card-header bg-dark text-white">
        Crear Usuario
    </div>
    <div class="card-body">
        <form action="" method="post">
            <div class="mb-3 row">
                <label for="" class="col-sm-2 form-label">Nombre Usuario</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="NombreUsuario" id="NombreUsuario" >
                </div>
            </div>
            <div class="mb-3 row">
                <label for="" class="col-sm-2 form-label">Contraseña</label>
                <div class="col-sm-10">
                    <input type="password" class="form-control" name="Contrasena" id="Contrasena" >
                </div>
            </div>
            <div class="mb-3 row">
                <label for="" class="col-sm-2 form-label">Fecha de Registro</label>
                <div class="col-sm-10">
                    <input type="date" class="form-control" name="FechaRegistro" id="FechaRegistro" >
                </div>
            </div>
            <div class="mb-3 row">
                <label for="" class="col-sm-2 form-label">Perfil</label>
                <div class="col-sm-10">
                    <select name="Perfil" id="Perfil" class="form-control">
                        <option value="" selected>Seleccione el Perfil</option>
                        <?php foreach($perfiles as $p) {?>
                        <option value="<?php echo $p->id_perfil?>"><?php echo $p->nombre_perfil?></option>

                        <?php }?>    
                    </select>
                </div>
            </div>
            <div class="mb-3 row">
                <div class="col-sm-2"></div>
                <div class="col-sm-10">
                    <input type="submit" class="btn btn-primary btn-lg" name="Guardar" id="Guardar" value="Guardar" >
                </div>
            </div>

        </form>
    </div>
</div>