<hr />
<div class="container">
    <div class="row">
        <div class="col-10"></div>
        <div class="col-2">
            <div class="d-grip gap2">
                <a href="?controller=usuarios&action=create" class="btn btn-success">Crear</a>
            </div>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-12">
            <table class="table table-striped">
            <thead>
                <th>Id Usuario</th>
                <th>Nombre Usuario</th>
                <th>Perfil</th>
                <th>Estado</th>
                <th>Fecha de Registro</th>
                <th>Editar</th>
                <th>Eliminar</th>
                <th>Datos Personales</th>
                <th>Proceso</th>
                

            </thead>
            <tbody>
                <?php 
                foreach($usuarios as $usu){
                   
                ?>
                <tr>
                <td><?php echo $usu->id_usuario?></td>
                <td><?php echo $usu->nombre_usuario?></td>
                <td><?php echo $usu->id_perfil?></td>
                <td><?php echo $usu->estado?></td>
                <td><?php echo $usu->fecha_registro?></td>
                <td><a href="?controller=usuarios&action=edit&id_usuario=<?php echo $usu->id_usuario?>" class="btn btn-primary">Editar</a></td>
                <td><a href="?controller=usuarios&action=inactivarUsuario&id_usuario=<?php echo $usu->id_usuario?>" class="btn btn-danger">Eliminar</a></td>
                <td><a href="?controller=datospersonales&action=show&id_usuario=<?php echo $usu->id_usuario?>" class="btn btn-warning">Datos</a></td>
                <td><a href="?controller=procesos&action=createProcesos&id_usuario=<?php echo $usu->id_usuario?>" class="btn btn-info">Crear</a></td>
                </tr>

                <?php
                }
                ?>
            </tbody>
            </table>
        </div>
    </div>
</div>
