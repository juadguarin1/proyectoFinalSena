<br/>
<div class="row">
    <div class="col-sm-3"></div>
    <div class="col-sm-6">
    <form method="post" action="">
  <!-- Email input -->
  <div class="form-outline mb-4">
    <input type="text" id="form2Example1" name="nombre_usuario"class="form-control" />
    <label class="form-label" for="form2Example1">Usuario</label>
  </div>

  <!-- Password input -->
  <div class="form-outline mb-4">
    <input type="password" id="form2Example2" name="contrasena" class="form-control" />
    <label class="form-label" for="form2Example2">Password</label>
  </div>



  <!-- Submit button -->
  <button type="submit" class="btn btn-primary btn-block mb-4">Ingresar</button>


</form>
    </div>
    <div class="col-sm-3"></div>
</div>
