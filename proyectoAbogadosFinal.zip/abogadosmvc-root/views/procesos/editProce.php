<br>
<div class="card">
    <div class="card-header bg-dark text-white">
        Actualizar Proceso
    </div>
    <div class="card-body">
        <form action="?controller=procesos&action=guardarEdicion" method="post">
        <div class="mb-3 row">
                <label for="" class="col-sm-2 form-label">Radicado del Proceso</label>
                <div class="col-sm-10">
                    <input type="hidden" name="id_detalle_proceso" value= "<?php echo $procesos->id_detalle_proceso?>">
                    <input type="text" class="form-control" name="radicado_proceso" id="radicado_proceso" value= "<?php echo $procesos->radicado_proceso?>">
                </div>
            </div>

            <div class="mb-3 row">
                <label for="" class="col-sm-2 form-label">Tipo de Proceso</label>
                <div class="col-sm-10">
                    <select name="tipo_proceso" id="tipo_proceso" class="form-control">
                        <option value="" selected>Seleccione el Tipo de Proceso</option>
                        <?php foreach($proceso as $p) {?>
                        <option value="<?php echo $p->id_tipo_proceso?>" <?php echo  'selected'?> ><?php echo $p->nombre_proceso?></option>

                        <?php }?>    
                    </select>
                </div>
            </div>

            <div class="mb-3 row">
                <label for="" class="col-sm-2 form-label">Asunto del proceso</label>
                <div class="col-sm-10">
                <textarea class="form-control"  id="asunto_proceso" name="asunto_proceso"  style="height: 70px"><?php echo $procesos->asunto_proceso?></textarea>
                </div>
            </div>

            <div class="mb-3 row">
                <label for="" class="col-sm-2 form-label">Demandante</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="demandante" id="demandante" value= "<?php echo $procesos->demandante?>">
                </div>
            </div>

            <div class="mb-3 row">
                <label for="" class="col-sm-2 form-label">Numero de documento</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="num_documento" id="num_documento" value= "<?php echo $procesos->num_documento?>" >
                </div>
            </div>

            <div class="mb-3 row">
                <label for="" class="col-sm-2 form-label">Demandado</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="demandado" id="demandado" value= "<?php echo $procesos->demandado?>" >
                </div>
            </div>

            <div class="mb-3 row">
                <label for="" class="col-sm-2 form-label">Juzgado</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="juzgado" id="juzgado" value= "<?php echo $procesos->juzgado?>">
                </div>
            </div>

            <div class="mb-3 row">
                <label for="" class="col-sm-2 form-label">Ciudad</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" name="ciudad" id="ciudad" value= "<?php echo $procesos->ciudad?>">
                </div>
            </div>

            <div class="mb-3 row">
                <label for="" class="col-sm-2 form-label">Fecha de la Demanda</label>
                <div class="col-sm-10">
                    <input type="date" class="form-control" name="fecha_demanda" id="fecha_demanda" value= "<?php echo $procesos->fecha_demanda?>">
                </div>
            </div>

            <div class="mb-3 row">
                <label for="" class="col-sm-2 form-label">Pretensiones</label>
                <div class="col-sm-10">
                <textarea class="form-control" placeholder="Pretensiones del proceso" id="pretensiones" name="pretensiones" style="height: 70px"><?php echo $procesos->pretensiones?></textarea>
                </div>
            </div>

            <div class="mb-3 row">
                <label for="" class="col-sm-2 form-label">Fecha de Contestacion</label>
                <div class="col-sm-10">
                    <input type="date" class="form-control" name="fecha_contestacion" id="fecha_contestacion" value= "<?php echo $procesos->fecha_contestacion?>">
                </div>
            </div>

            <div class="mb-3 row">
                <label for="" class="col-sm-2 form-label">Excepciones</label>
                <div class="col-sm-10">
                <textarea class="form-control" placeholder="Excepciones del proceso" id="excepciones" name="excepciones" style="height: 70px"><?php echo $procesos->excepciones?></textarea>
                </div>
            </div>

            <div class="mb-3 row">
                <label for="" class="col-sm-2 form-label">Fecha de Audiencia 1</label>
                <div class="col-sm-10">
                    <input type="date" class="form-control" name="fecha_audiencia1" id="fecha_audiencia1" value= "<?php echo $procesos->fecha_audiencia1?>">
                </div>
            </div>

            <div class="mb-3 row">
                <label for="" class="col-sm-2 form-label">Fecha de Audiencia 2</label>
                <div class="col-sm-10">
                    <input type="date" class="form-control" name="fecha_audiencia2" id="fecha_audiencia2" value= "<?php echo $procesos->fecha_audiencia2?>">
                </div>
            </div>

            <div class="mb-3 row">
                <label for="" class="col-sm-2 form-label">Fecha de Audiencia 3</label>
                <div class="col-sm-10">
                    <input type="date" class="form-control" name="fecha_audiencia3" id="fecha_audiencia3" value= "<?php echo $procesos->fecha_audiencia3?>">
                </div>
            </div>

            <div class="mb-3 row">
                <label for="" class="col-sm-2 form-label">Fecha de Audiencia 4</label>
                <div class="col-sm-10">
                    <input type="date" class="form-control" name="fecha_audiencia4" id="fecha_audiencia4" value= "<?php echo $procesos->fecha_audiencia4?>">
                </div>
            </div>

            <div class="mb-3 row">
                <label for="" class="col-sm-2 form-label">Observaciones</label>
                <div class="col-sm-10">
                <textarea class="form-control" placeholder="Excepciones del proceso" id="observaciones" name="observaciones" style="height: 90px"><?php echo $procesos->observaciones?></textarea>
                </div>
            </div>

            <div class="mb-3 row">
                <label for="" class="col-sm-2 form-label">Subir archivos</label>
                <div class="col-sm-10">
                <input type="file" name="cargar_archivos" id="cargar_archivos">
                </div>
            </div>


            
            <div class="mb-3 row">
                <div class="col-sm-2"></div>
                <div class="col-sm-10">
                    <input type="submit" class="btn btn-primary btn-lg" name="Guardar" id="Guardar" value="Guardar" >
                </div>
            </div>

        </form>
    </div>
</div>