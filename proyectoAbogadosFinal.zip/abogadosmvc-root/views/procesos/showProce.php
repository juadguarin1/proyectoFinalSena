<hr />
<div class="container">
    <div class="row">
        <div class="col-10"></div>
        
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-12">
            <table class="table table-striped">
            <thead>
                <th>Id Detalle de Proceso</th>
                <th>Radicado Proceso</th>
                <th>Tipo de Proceso</th>
                <th>Ciudad</th>
                <th>Demandante</th>
                <th>Detalles de Proceso</th>
                

            </thead>
            <tbody>
                <?php 
                foreach($procesos as $pro){
                   
                ?>
                <tr>
                <td><?php echo $pro->id_detalle_proceso?></td>
                <td><?php echo $pro->radicado_proceso?></td>
                <td><?php echo $pro->tipo_proceso?></td>
                <td><?php echo $pro->ciudad?></td>
                <td><?php echo $pro->demandante?></td>
                <td><a href="?controller=procesos&action=edit&id_detalle_proceso=<?php echo $pro->id_detalle_proceso?>" class="btn btn-primary">Editar</a></td>
                
                </tr>

                <?php
                }
                ?>
            </tbody>
            </table>
        </div>
    </div>
</div>