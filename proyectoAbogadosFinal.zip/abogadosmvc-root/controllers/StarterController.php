<?php
include_once "models/Usuarios.php";
include_once "config/conexion.php";

class StarterController{
    public function __construct(){
        session_start();
    }
}