<?php 
include_once("models/Usuarios.php");
include_once("models/Procesos.php");
include_once("config/conexion.php");
include_once("StarterController.php");

$su = new StarterController();

class UsuariosController{

    public function showLogin(){
        if($_POST)
        {
            $nombre_usuario= $_POST['nombre_usuario'];
            $contrasena= $_POST['contrasena'];
            $userName= Usuarios::buscarByUser($nombre_usuario);

            if(password_verify($contrasena,$userName->contrasena)&&($nombre_usuario==$userName->nombre_usuario))
            {
                $_SESSION['nombre_usuario']=$userName->nombre_usuario;
                $_SESSION['id_perfil']=$userName->id_perfil;
                header("Location:./?controller=page&action=home " );
            }else{
                include_once"views/pages/invalid-login.php";
            }
        }
        
        include_once("views/login/login.php");
    }

    public function show(){
        $usuarios= Usuarios::showData();
        include_once("views/usuarios/show.php");
    }

    public function create(){
        
        if($_POST){
            
            
            $estado= "Activo";
            $id_perfil= $_POST['Perfil'];
            $nombre_usuario= $_POST['NombreUsuario'];
            $fecha_registro= $_POST['FechaRegistro'];
            $contrasena= password_hash($_POST['Contrasena'],PASSWORD_BCRYPT) ;

            Usuarios::createUsuario($contrasena,$estado,$id_perfil,$nombre_usuario,$fecha_registro);

            
            header("Location:./?controller=usuarios&action=show " );
        }
        
        $perfiles= Usuarios::cargarPerfiles();
        include_once("views/usuarios/create.php");
    }

    public function showPerfiles(){
        $perfiles= Usuarios::cargarPerfiles();
        
    }

    public function home(){
        
        include_once("views/pages/home.php");

        }

    

    public function edit(){
        $perfiles= Usuarios::cargarPerfiles();

        $id_usuario=$_GET['id_usuario'];
        $usuario= Usuarios::search($id_usuario);
        $estados = array("Activo","Inactivo");

        include_once("views/usuarios/edit.php");
    }

    public function guardarEdicion(){
        $id_usuario = $_POST['id_usuario'];
        $contrasena= $_POST['Contrasena'];
        $estado= $_POST['Estado'];
        $id_perfil= $_POST['Perfil'];
        $nombre_usuario= $_POST['NombreUsuario'];
        $fecha_registro= $_POST['FechaRegistro'];
        Usuarios::editUsuario($contrasena,$estado,$id_perfil,$nombre_usuario,$fecha_registro,$id_usuario);
        header("Location:./?controller=usuarios&action=show " );
    }

    public function inactivarUsuario(){
        $id_usuario=$_GET["id_usuario"];
        Usuarios::inactivarUsuario($id_usuario);
        header("Location:./?controller=usuarios&action=show " );
    }


  
    
    
}