<?php 
include_once("models/DatosPersonales.php");
include_once("config/conexion.php");

class DatosPersonalesController{

    public function show(){
        $id_usuario= $_GET["id_usuario"];
        $tiene_datos = DatosPersonales::cargarId($id_usuario);
        if(!empty($tiene_datos)){
            $datosPersonales= DatosPersonales::mostrarDatosPersonales($id_usuario);
        }else {
            $datosPersonales = new DatosPersonales($id_usuario,
            "","","","","","", "","","", "", "");
        }

        $tiposDocumento= DatosPersonales::cargarTiposDocumento();
        include_once("views/usuarios/datospersonales.php");
    }

    public function enviarDatosPersonales(){

        
        if($_POST){
            $id_usuario= $_POST['txtid_usuario'];
            $num_documento= $_POST['txtnumdocumento'];
            $tipo_documento= $_POST['cboid_tipodocumento'];
            $nombres = $_POST['txtnombre_usuario'];
            $apellidos= $_POST['txtapellidos'];
            $fecha_naci= $_POST['fecha_naci'];
            $genero= $_POST['cbogenero'];
            $celular = $_POST['txtcelular'];
            $direccion= $_POST['txtdireccion'];
            $email= $_POST['txtemail'];
            $telefono= $_POST['txtelefono'];

            $tiene_datos = DatosPersonales::cargarId($id_usuario);
            if(!empty($tiene_datos)){
                DatosPersonales::actualizarDatosPersonales($num_documento,$tipo_documento, $nombres, $apellidos,$fecha_naci, $genero, $celular, $direccion,$email, $telefono,$id_usuario);
            }else {
                DatosPersonales::insertarDatosPersonales($id_usuario,$num_documento,$tipo_documento, $nombres, $apellidos,$fecha_naci, $genero, $celular, $direccion,$email, $telefono);
            }

            header("Location:./?controller=usuarios&action=show" );
        }
    }


}
