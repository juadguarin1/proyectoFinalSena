<?php 
include_once("models/Procesos.php");
include_once("models/TipoProce.php");
include_once("config/conexion.php");

class ProcesosController{
    public function showProcesos(){
        $procesos= Procesos::mostrarProcesos();
        include_once("views/procesos/showProce.php");
    }
    
    public function createProcesos(){
        
        if($_POST){
            
            $radicado_proceso= $_POST['radicado_proceso'];
            $tipo_proceso= $_POST['tipo_proceso'];
            $asunto_proceso= $_POST['asunto_proceso'];
            $demandante= $_POST['demandante'];
            $demandado= $_POST['demandado'];
            $juzgado= $_POST['juzgado'];
            $ciudad= $_POST['ciudad'];
            $fecha_demanda= $_POST['fecha_demanda'];
            $pretensiones= $_POST['pretensiones'];
            $fecha_contestacion= $_POST['fecha_contestacion'];
            $excepciones= $_POST['excepciones'];
            $fecha_audiencia1= $_POST['fecha_audiencia1'];
            $observaciones= $_POST['observaciones'];
            $fecha_audiencia2= $_POST['fecha_audiencia2'];
            $fecha_audiencia3= $_POST['fecha_audiencia3'];
            $fecha_audiencia4= $_POST['fecha_audiencia4'];
            $num_documento= $_POST['num_documento'];
            $cargar_archivos= $_POST['cargar_archivos'];
            
           

            Procesos::crearProceso($radicado_proceso,$tipo_proceso,$asunto_proceso,$demandante,$demandado,$juzgado,$ciudad,$fecha_demanda,$pretensiones,$fecha_contestacion,$excepciones,$fecha_audiencia1,$observaciones,$fecha_audiencia2,$fecha_audiencia3,$fecha_audiencia4,$num_documento,$cargar_archivos);

            
            header("Location:./?controller=procesos&action=showProcesos " );
        }
        
        $procesos= TipoProces::cargarTiposProcesos();
        include_once("views/procesos/createProce.php");
    }

    public function edit(){

        
        $id_detalle_proceso=$_GET["id_detalle_proceso"];
        $procesos= Procesos::search($id_detalle_proceso);
        $proceso= TipoProces::cargarTiposProcesos();
        

        include_once("views/procesos/editProce.php");
        
    }

    public function guardarEdicion(){
            $id_detalle_proceso=$_POST['id_detalle_proceso'];
            $radicado_proceso= $_POST['radicado_proceso'];
            $tipo_proceso= $_POST['tipo_proceso'];
            $asunto_proceso= $_POST['asunto_proceso'];
            $demandante= $_POST['demandante'];
            $demandado= $_POST['demandado'];
            $juzgado= $_POST['juzgado'];
            $ciudad= $_POST['ciudad'];
            $fecha_demanda= $_POST['fecha_demanda'];
            $pretensiones= $_POST['pretensiones'];
            $fecha_contestacion= $_POST['fecha_contestacion'];
            $excepciones= $_POST['excepciones'];
            $fecha_audiencia1= $_POST['fecha_audiencia1'];
            $observaciones= $_POST['observaciones'];
            $fecha_audiencia2= $_POST['fecha_audiencia2'];
            $fecha_audiencia3= $_POST['fecha_audiencia3'];
            $fecha_audiencia4= $_POST['fecha_audiencia4'];
            $num_documento= $_POST['num_documento'];
            $cargar_archivos= $_POST['cargar_archivos'];
        Procesos::editProcesos($radicado_proceso,$tipo_proceso,$asunto_proceso,$demandante,$demandado,$juzgado,$ciudad,$fecha_demanda,$pretensiones,$fecha_contestacion,$excepciones,$fecha_audiencia1,$observaciones,$fecha_audiencia2,$fecha_audiencia3,$fecha_audiencia4,$num_documento,$cargar_archivos,$id_detalle_proceso);
        $proceso= TipoProces::cargarTiposProcesos();
        header("Location:./?controller=procesos&action=showProcesos " );
    }


}