<?php
class Procesos{
    
    public $id_detalle_proceso;
    public $radicado_proceso;
    public $tipo_proceso;
    public $asunto_proceso;
    public $demandante;
    public $demandado;
    public $juzgado;
    public $ciudad;
    public $fecha_demanda;
    public $pretensiones;
    public $fecha_contestacion;
    public $excepciones;
    public $fecha_audiencia1;
    public $observaciones;
    public $fecha_audiencia2;
    public $fecha_audiencia3;
    public $fecha_audiencia4;
    public $num_documento;
    public $cargar_archivos;

    public function __construct($id_detalle_proceso,$radicado_proceso,$tipo_proceso,$asunto_proceso,$demandante,$demandado,$juzgado,$ciudad,$fecha_demanda,$pretensiones,$fecha_contestacion,$excepciones,$fecha_audiencia1,$observaciones,$fecha_audiencia2,$fecha_audiencia3,$fecha_audiencia4,$num_documento,$cargar_archivos)
    {
        $this->id_detalle_proceso=$id_detalle_proceso;
        $this->radicado_proceso=$radicado_proceso;
        $this->tipo_proceso=$tipo_proceso;
        $this->asunto_proceso=$asunto_proceso;
        $this->demandante=$demandante;
        $this->demandado=$demandado;
        $this->juzgado=$juzgado;
        $this->ciudad=$ciudad;
        $this->fecha_demanda=$fecha_demanda;
        $this->pretensiones=$pretensiones;
        $this->fecha_contestacion=$fecha_contestacion;
        $this->excepciones=$excepciones;
        $this->fecha_audiencia1=$fecha_audiencia1;
        $this->observaciones=$observaciones;
        $this->fecha_audiencia2=$fecha_audiencia2;
        $this->fecha_audiencia3=$fecha_audiencia3;
        $this->fecha_audiencia4=$fecha_audiencia4;
        $this->num_documento=$num_documento;
        $this->cargar_archivos=$cargar_archivos;
    }

    public static function mostrarProcesos(){
        $listaProcesos=[];
        $cnn=BD::conection();
        $sql=$cnn->query("SELECT d.id_detalle_proceso,d.radicado_proceso,t.nombre_proceso,d.asunto_proceso,d.demandante,d.demandado,d.juzgado,d.ciudad,d.fecha_demanda,d.pretensiones,d.fecha_contestacion,d.excepciones,d.fecha_audiencia1,d.observaciones,d.fecha_audiencia2,d.fecha_audiencia3,d.fecha_audiencia4,d.num_documento,d.cargar_archivos FROM detalles_proceso d 
        inner join tipo_proceso t on d.tipo_proceso=t.id_tipo_proceso");

        foreach($sql->fetchAll() as $procesos){
            $listaProcesos[]= new Procesos($procesos['id_detalle_proceso'],$procesos['radicado_proceso'],$procesos['nombre_proceso'],$procesos['asunto_proceso'],$procesos['demandante'],$procesos['demandado'],$procesos['juzgado'],$procesos['ciudad'],$procesos['fecha_demanda'],$procesos['pretensiones'],$procesos['fecha_contestacion'],$procesos['excepciones'],$procesos['fecha_audiencia1'],$procesos['observaciones'],$procesos['fecha_audiencia2'],$procesos['fecha_audiencia3'],$procesos['fecha_audiencia4'],$procesos['num_documento'],$procesos['cargar_archivos']);
        }
        return $listaProcesos;
    }

    

    public static function crearProceso($radicado_proceso,$tipo_proceso,$asunto_proceso,$demandante,$demandado,$juzgado,$ciudad,$fecha_demanda,$pretensiones,$fecha_contestacion,$excepciones,$fecha_audiencia1,$observaciones,$fecha_audiencia2,$fecha_audiencia3,$fecha_audiencia4,$num_documento,$cargar_archivos){
        
        $cnn=BD::conection();
        $sql=$cnn-> prepare("INSERT INTO detalles_proceso(radicado_proceso, tipo_proceso, asunto_proceso, demandante, demandado,juzgado,ciudad,fecha_demanda,pretensiones,fecha_contestacion,excepciones,fecha_audiencia1,observaciones,fecha_audiencia2,fecha_audiencia3,fecha_audiencia4,num_documento,cargar_archivos) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        $sql->execute(array($radicado_proceso,$tipo_proceso,$asunto_proceso,$demandante,$demandado,$juzgado,$ciudad,$fecha_demanda,$pretensiones,$fecha_contestacion,$excepciones,$fecha_audiencia1,$observaciones,$fecha_audiencia2,$fecha_audiencia3,$fecha_audiencia4,$num_documento,$cargar_archivos));
      
        
    }

    public static function search($id_detalle_proceso) {

        $cnn = BD::conection();
        $sql=$cnn-> prepare("SELECT d.id_detalle_proceso,d.radicado_proceso,t.nombre_proceso,d.asunto_proceso,d.demandante,d.demandado,d.juzgado,d.ciudad,d.fecha_demanda,d.pretensiones,d.fecha_contestacion,d.excepciones,d.fecha_audiencia1,d.observaciones,d.fecha_audiencia2,d.fecha_audiencia3,d.fecha_audiencia4,d.num_documento,d.cargar_archivos FROM detalles_proceso d 
        inner join tipo_proceso t on d.tipo_proceso=t.id_tipo_proceso and d.id_detalle_proceso = ?");
        $sql->execute(array($id_detalle_proceso));
       
        $procesos = $sql->fetch();
    
        return new Procesos($procesos['id_detalle_proceso'],$procesos['radicado_proceso'],$procesos['nombre_proceso'],$procesos['asunto_proceso'],$procesos['demandante'],$procesos['demandado'],$procesos['juzgado'],$procesos['ciudad'],$procesos['fecha_demanda'],$procesos['pretensiones'],$procesos['fecha_contestacion'],$procesos['excepciones'],$procesos['fecha_audiencia1'],$procesos['observaciones'],$procesos['fecha_audiencia2'],$procesos['fecha_audiencia3'],$procesos['fecha_audiencia4'],$procesos['num_documento'],$procesos['cargar_archivos']);
    
    }
    
    public static function editProcesos($id_detalle_proceso,$radicado_proceso,$tipo_proceso,$asunto_proceso,$demandante,$demandado,$juzgado,$ciudad,$fecha_demanda,$pretensiones,$fecha_contestacion,$excepciones,$fecha_audiencia1,$observaciones,$fecha_audiencia2,$fecha_audiencia3,$fecha_audiencia4,$num_documento,$cargar_archivos){
            
        $cnn=BD::conection();
        $sql=$cnn-> prepare("UPDATE detalles_proceso SET radicado_proceso=?, tipo_proceso=?, asunto_proceso=?, demandante=?, demandado=?,juzgado=?,ciudad=?,fecha_demanda=?,pretensiones=?,fecha_contestacion=?,excepciones=?,fecha_audiencia1=?,observaciones=?,fecha_audiencia2=?,fecha_audiencia3=?,fecha_audiencia4=?,num_documento=?,cargar_archivos=? WHERE id_detalle_proceso=?");
        $sql->execute(array($id_detalle_proceso,$radicado_proceso,$tipo_proceso,$asunto_proceso,$demandante,$demandado,$juzgado,$ciudad,$fecha_demanda,$pretensiones,$fecha_contestacion,$excepciones,$fecha_audiencia1,$observaciones,$fecha_audiencia2,$fecha_audiencia3,$fecha_audiencia4,$num_documento,$cargar_archivos));
      
        
    }




}