<?php
class Usuarios{
    
    public $id_usuario;
    public $contrasena;
    public $estado;
    public $id_perfil;
    public $nombre_usuario;
    public $fecha_registro;

    public function __construct($id_usuario,$contrasena,$estado,$id_perfil,$nombre_usuario,$fecha_registro)
    {
       $this->id_usuario=$id_usuario;
       $this->contrasena=$contrasena;
       $this->estado=$estado;
       $this->id_perfil=$id_perfil;
       $this->nombre_usuario=$nombre_usuario;
       $this->fecha_registro=$fecha_registro;
    }

    public static function showData(){
        $listaUsuarios=[];
        $cnn=BD::conection();
        $sql=$cnn->query("SELECT u.id_usuario,u.contrasena,u.nombre_usuario,p.nombre_perfil,u.estado,u.fecha_registro FROM usuarios u 
        inner join perfil p on u.id_perfil=p.id_perfil WHERE estado='Activo'");

        foreach($sql->fetchAll() as $usuarios){
            $listaUsuarios[]= new Usuarios($usuarios['id_usuario'],$usuarios['contrasena'],$usuarios['estado'],$usuarios['nombre_perfil'],$usuarios['nombre_usuario'],$usuarios['fecha_registro']);
        }
        return $listaUsuarios;
    }

    

    public static function createUsuario($contrasena,$estado,$id_perfil,$nombre_usuario,$fecha_registro){
        
        $cnn=BD::conection();
        $sql=$cnn-> prepare("INSERT INTO usuarios(contrasena, estado, id_perfil, nombre_usuario, fecha_registro) VALUES(?,?,?,?,?)");
        $sql->execute(array($contrasena,$estado,$id_perfil,$nombre_usuario,$fecha_registro));
      
        
    }

    public static function cargarPerfiles(){
        $cnn=BD::conection();
        $sql=$cnn->prepare("SELECT * FROM perfil");
        $sql->execute();
        $objList= $sql->fetchAll(PDO::FETCH_OBJ);
            return $objList;
    }


    public static function search($id_usuario) {

        $cnn = BD::conection();
        $sql=$cnn-> prepare("SELECT u.id_usuario,u.contrasena,u.nombre_usuario,p.id_perfil,p.nombre_perfil,u.estado,u.fecha_registro FROM usuarios u
        inner join perfil p on u.id_perfil=p.id_perfil and u.id_usuario = ?");
        $sql->execute(array($id_usuario));
       
        $usuario = $sql->fetch();
    
        return new Usuarios($usuario['id_usuario'],$usuario['contrasena'],$usuario['estado'],$usuario['id_perfil'],$usuario['nombre_usuario'],$usuario['fecha_registro']);
    
    }

    public static function editUsuario($contrasena,$estado,$id_perfil,$nombre_usuario,$fecha_registro,$id_usuario){
        
        $cnn=BD::conection();
        $sql=$cnn-> prepare("UPDATE usuarios SET contrasena = ?, estado=?, id_perfil=?, nombre_usuario=?, fecha_registro=? WHERE id_usuario=?");
        $sql->execute(array($contrasena,$estado,$id_perfil,$nombre_usuario,$fecha_registro,$id_usuario));
      
        
    }

    public static function inactivarUsuario($id_usuario){
        
        $cnn=BD::conection();
        $sql=$cnn-> prepare("UPDATE usuarios SET estado='Inactivo' WHERE id_usuario=?");
        $sql->execute(array($id_usuario));
      
        
    }

    


    public static function buscarByUser($nombre_usuario){
            $cnn= BD::conection();
            $sql=$cnn->prepare("SELECT * from usuarios WHERE nombre_usuario= ?");
            $sql->execute(array($nombre_usuario));

            $usuario = $sql->fetch();

            return new Usuarios($usuario['nombre_usuario'],$usuario['nombre_usuario'],$usuario['contrasena'],$usuario['estado'],$usuario['id_perfil'],$usuario['fecha_registro']);
    }

}

