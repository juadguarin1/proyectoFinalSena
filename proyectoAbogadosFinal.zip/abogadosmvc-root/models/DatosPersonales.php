<?php
class DatosPersonales{
    public $id_usuario;
    public $num_documento;
    public $tipo_documento;
    public $nombre_documento;
    public $nombres;
    public $apellidos;
    public $fecha_naci;
    public $genero;
    public $celular;
    public $direccion;
    public $email;
    public $telefono;

    public function __construct($id_usuario,$num_documento,$tipo_documento,$nombre_documento,$nombres,$apellidos,$fecha_naci, $genero,$celular,$direccion, $email, $telefono)
    {
       $this->id_usuario=$id_usuario;
       $this->num_documento=$num_documento;
       $this->tipo_documento=$tipo_documento;
       $this->nombre_documento=$nombre_documento;
       $this->nombres=$nombres;
       $this->apellidos=$apellidos;
       $this->fecha_naci=$fecha_naci;
       $this->genero=$genero;
       $this->celular=$celular;
       $this->direccion=$direccion;
       $this->email=$email;
       $this->telefono=$telefono;

    }

    public static function cargarId($id_usuario){
        try{
            
            $cnn=BD::conection();
            $sql=$cnn->prepare("SELECT * from datos_personales WHERE id_usuario =?");
            $sql->execute (array ($id_usuario));
            return $sql->fetch(PDO::FETCH_OBJ);
        }catch (Exception $e){
            die($e->getMessage());
        }
    }

    public static function mostrarDatosPersonales($id_usuario){
        try{
        $cnn=BD::conection();
        $sql=$cnn->prepare("SELECT dp.id_usuario, dp.num_documento, dp.tipo_documento, tp.nombre_documento, dp.nombres, dp.apellidos, dp.fecha_naci, dp.genero, dp.celular, dp.direccion, dp.email, dp.telefono FROM datos_personales dp INNER JOIN tipo_documentos tp on tp.id_tipo_documento= dp.tipo_documento WHERE id_usuario =?");
        $sql->execute (array ($id_usuario));
        $datos = $sql->fetch();
            return new DatosPersonales ($datos['id_usuario'],$datos['num_documento'], $datos['tipo_documento'],$datos['nombre_documento'],$datos['nombres'],$datos['apellidos'],$datos['fecha_naci'],$datos['genero'],$datos['celular'],$datos['direccion'],$datos['email'],$datos['telefono']);
        }catch (Exception $e){
            die($e->getMessage());
        }
    }

    public static function cargarTiposDocumento(){
        $cnn=BD::conection();
        $sql=$cnn->prepare("SELECT * FROM tipo_documentos");
        $sql->execute();
        $objList= $sql->fetchAll(PDO::FETCH_OBJ);
            return $objList;
    }

    public static function insertarDatosPersonales ($id_usuario,$num_documento,$tipo_documento, $nombres, $apellidos,$fecha_naci, $genero, $celular, $direccion,$email, $telefono){
        $cnn=BD::conection();
        $sql=$cnn->prepare("INSERT INTO datos_personales (id_usuario, num_documento, tipo_documento, nombres, apellidos,fecha_naci,genero,celular,direccion,email,telefono) VALUES(?,?,?,?,?,?,?,?,?,?,?)");
        $sql->execute (array ($id_usuario,$num_documento,$tipo_documento, $nombres, $apellidos,$fecha_naci, $genero, $celular, $direccion,$email, $telefono));

    }

    public static function actualizarDatosPersonales ($num_documento,$tipo_documento, $nombres, $apellidos,$fecha_naci, $genero, $celular, $direccion,$email, $telefono,$id_usuario){
        $cnn=BD::conection();
        $sql=$cnn->prepare("UPDATE datos_personales SET num_documento=?, tipo_documento=?, nombres=?, apellidos=?,fecha_naci=?,genero=?,celular=?,direccion=?,email=?,telefono=? WHERE id_usuario=?");
        $sql->execute (array ($num_documento,$tipo_documento, $nombres, $apellidos,$fecha_naci, $genero, $celular, $direccion,$email, $telefono,$id_usuario));
    }
}