<?php
class TipoProces{
    public $id_tipo_proceso;
    public $nombre_proceso;

    public function __construct($id_tipo_proceso,$nombre_proceso)
    {
       $this->id_tipo_proceso=$id_tipo_proceso;
       $this->nombre_proceso=$nombre_proceso;

    }

    public static function cargarTiposProcesos(){
        $cnn=BD::conection();
        $sql=$cnn->prepare("SELECT * FROM tipo_proceso");
        $sql->execute();
        $objList= $sql->fetchAll(PDO::FETCH_OBJ);
            return $objList;
    }

    
}